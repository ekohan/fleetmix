from .vrp_to_fsm import main

if __name__ == "__main__":
    main() 